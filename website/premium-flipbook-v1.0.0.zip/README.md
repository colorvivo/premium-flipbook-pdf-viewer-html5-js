# Premium FlipBook PDF Viewer

A complete flipbook PDF/image viewer library with WebGL 3D, CSS 3D/2D, and Swipe rendering modes. Pure JavaScript (no jQuery), modular architecture, comprehensive UI.

## Features

- **Multiple Renderers**: WebGL 3D (Three.js), CSS 3D transforms, Swipe mode
- **Multiple Sources**: PDF files, image arrays, optimized images with JSON
- **Responsive Design**: Auto-switches between single/double page modes
- **Touch Support**: Swipe navigation, pinch zoom, double-tap
- **Rich UI**: Toolbar, thumbnails, table of contents, search
- **Deep Linking**: Hash-based URL navigation
- **Lightbox Mode**: Modal overlay display
- **Autoplay**: Automatic page flipping
- **Sound Effects**: Page flip sounds
- **Keyboard Navigation**: Full keyboard support
- **Accessibility**: ARIA labels, focus management

## Installation

```bash
npm install premium-flipbook-pdf-viewer
```

Or include via CDN:

```html
<link rel="stylesheet" href="https://unpkg.com/premium-flipbook-pdf-viewer/dist/premium-flipbook.css">
<script src="https://unpkg.com/premium-flipbook-pdf-viewer/dist/premium-flipbook.min.js"></script>
```

## Quick Start

### With Images (No Dependencies)

```javascript
import PremiumFlipBook from 'premium-flipbook-pdf-viewer';

const flipbook = new PremiumFlipBook({
  container: '#flipbook',
  images: [
    'pages/page1.jpg',
    'pages/page2.jpg',
    'pages/page3.jpg'
  ]
});
```

### With PDF

```javascript
import PremiumFlipBook from 'premium-flipbook-pdf-viewer';

const flipbook = new PremiumFlipBook({
  container: '#flipbook',
  pdfUrl: 'document.pdf'
});
```

### With Optimized Source

```javascript
const flipbook = new PremiumFlipBook({
  container: '#flipbook',
  optimizedImages: {
    jsonUrl: 'magazine/config.json'
  }
});
```

## Configuration

```javascript
const flipbook = new PremiumFlipBook({
  // Container
  container: '#flipbook',       // Selector or element
  width: 'auto',                // Width (number, 'auto', '100%')
  height: 'auto',               // Height
  aspectRatio: 1.414,           // A4 ratio

  // Source (choose one)
  pdfUrl: 'document.pdf',
  images: ['page1.jpg', 'page2.jpg'],
  optimizedImages: { jsonUrl: 'config.json' },

  // Rendering
  renderMode: 'auto',           // 'webgl', 'css', 'swipe', 'auto'
  singlePageMode: 'auto',       // 'auto', 'always', 'never'
  singlePageBreakpoint: 768,
  rtl: false,
  startPage: 1,

  // Zoom
  zoom: {
    enabled: true,
    min: 1,
    max: 4,
    step: 0.25,
    wheelZoom: true,
    pinchZoom: true
  },

  // UI
  ui: {
    toolbar: {
      enabled: true,
      position: 'bottom',
      buttons: ['first', 'prev', 'pageInput', 'next', 'last', 'separator', 'fullscreen']
    },
    thumbnails: { enabled: true },
    toc: { enabled: true },
    search: { enabled: true }
  },

  // Features
  features: {
    deepLinking: true,
    fullscreen: true,
    lightbox: false,
    download: false,
    autoplay: { enabled: false, interval: 5000 },
    sound: { enabled: false }
  },

  // Callbacks
  onReady: (flipbook) => {},
  onPageChange: ({ page, totalPages }) => {},
  onFlipStart: ({ direction }) => {},
  onFlipEnd: ({ page }) => {},
  onError: (error) => {}
});
```

## Demos

See all features in action: [Demo Gallery](./examples/index.html)

- Basic PDF / Image sources
- WebGL, CSS 3D, and Swipe renderers
- Page transitions (fade, slide, flip, none)
- Zoom & pan, thumbnails, keyboard navigation
- Autoplay, lightbox, RTL support

## API

### Navigation

```javascript
flipbook.goToPage(5);       // Go to specific page
flipbook.nextPage();        // Next page
flipbook.prevPage();        // Previous page
flipbook.firstPage();       // First page
flipbook.lastPage();        // Last page
```

### Transitions & Display

```javascript
flipbook.setTransition('fade');     // Set transition: 'fade', 'slide', 'flip', 'none'
flipbook.setDisplayMode('single');  // Display mode: 'single' or 'double'
flipbook.getDisplayMode();          // Get current display mode
```

### Zoom

```javascript
flipbook.setZoom(2);        // Set zoom level
flipbook.zoomIn();          // Zoom in
flipbook.zoomOut();         // Zoom out
flipbook.resetZoom();       // Reset to 1x
```

### UI

```javascript
flipbook.toggleThumbnails();
flipbook.toggleTOC();
flipbook.toggleSearch();
flipbook.toggleFullscreen();
```

### State

```javascript
flipbook.getCurrentPage();  // Current page number
flipbook.getPageCount();    // Total pages
flipbook.getZoom();         // Current zoom level
flipbook.isFlipping();      // Animation in progress
```

### Events

```javascript
flipbook.on('pageChange', ({ page }) => {});
flipbook.on('flipStart', ({ direction }) => {});
flipbook.on('flipEnd', ({ page }) => {});
flipbook.on('zoomChange', ({ zoom }) => {});
flipbook.on('fullscreenChange', ({ isFullscreen }) => {});
```

### Lifecycle

```javascript
flipbook.destroy();         // Clean up
```

## Optimized Source Format

For maximum performance, pre-render your PDF to images and create a JSON config:

```json
{
  "title": "My Magazine",
  "pageWidth": 800,
  "pageHeight": 1131,
  "pages": [
    {
      "src": "pages/page1.jpg",
      "thumb": "thumbs/page1.jpg",
      "text": "Searchable text content...",
      "title": "Chapter 1"
    }
  ],
  "toc": [
    { "title": "Introduction", "page": 1 },
    { "title": "Chapter 1", "page": 3 }
  ]
}
```

Use the CLI tool to generate this from a PDF:

```bash
npx pfb-convert document.pdf --output ./magazine
```

## Browser Support

- Chrome 70+
- Firefox 65+
- Safari 12+
- Edge 79+

## Dependencies

- **Required**: None (for image source with CSS renderer)
- **Optional**: PDF.js (for PDF source)
- **Optional**: Three.js (for WebGL renderer)

## Download

Download the latest release:
- [Download ZIP](./website/premium-flipbook-v1.0.0.zip) - Complete package with source, dist, and examples
- [GitHub Releases](https://github.com/colorvivo/premium-flipbook-pdf-viewer/releases)

## Documentation

Full documentation is available in HTML format:
- [API Reference](./examples/docs-api.html)
- [Options Reference](./examples/docs-options.html)
- [Usage Guide](./examples/docs-usage.html)
- [Events Reference](./examples/docs-events.html)
- [Troubleshooting](./examples/docs-troubleshooting.html)

## Website

Visit the product website: [website/index.html](./website/index.html)

## License

MIT License

## Links

- [Website](./website/index.html)
- [Demo Gallery](./examples/index.html)
- [GitHub Repository](https://github.com/colorvivo/premium-flipbook-pdf-viewer)
- [Report Issues](https://github.com/colorvivo/premium-flipbook-pdf-viewer/issues)
